# Agenda-IA: Intelligent Productivity Platform

An intelligent productivity platform leveraging advanced AI technologies to transform task management and user engagement, with a focus on intuitive design and adaptive user experience.

Este es el repositorio oficial del proyecto Agenda-IA.

## 🌟 Key Features / Características

- **AI-Powered Task Optimization**: Intelligent scheduling and prioritization
- **Real-Time Productivity Tracking**: Adaptive insights based on your work patterns
- **Personalized Task Suggestions**: AI-generated recommendations to improve productivity
- **Dynamic Calendar Management**: Flexible event scheduling with recurrence support
- **Comprehensive Analytics**: Track and visualize your productivity trends
- **User-Friendly Interface**: Intuitive design for seamless interaction
- **Gestión completa de eventos y calendarios**
- **Detección de conflictos entre eventos**
- **Sugerencias inteligentes de horarios mediante IA**
- **Optimización automática de agenda**
- **Evaluación de eficiencia**
- **Sistema de notificaciones**

## 🔧 Technology Stack / Stack Tecnológico

- **Frontend**: React with TypeScript, Tailwind CSS, shadcn UI components
- **Backend**: Node.js with Express / Python
- **Database**: MongoDB for flexible document storage
- **Real-Time Communication**: WebSockets for instant updates
- **AI Integration**: Advanced AI-powered suggestions and productivity insights
- **Form Handling**: React Hook Form with Zod validation
- **State Management**: React Query for server state, Zustand for client state

## 📊 Project Structure / Estructura del Proyecto

### JavaScript/TypeScript Version:
```
/
├── client/                # Frontend application
│   ├── src/
│   │   ├── components/    # UI components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utility functions
│   │   ├── pages/         # Application pages
│   │   ├── App.tsx        # Main application component
│   │   └── main.tsx       # Application entry point
├── server/                # Backend server
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes
│   ├── db.ts              # Database connection
│   ├── mongodb.ts         # MongoDB configuration
│   ├── mongoModels.ts     # MongoDB schema models
│   └── mongoStorage.ts    # MongoDB storage interface
├── shared/                # Shared code between frontend and backend
│   └── schema.ts          # Data models and validation schemas
└── public/                # Static assets
```

### Python Version:
```
back/
├── controllers/
│   ├── __init__.py
│   ├── evento_controller.py
│   ├── calendario_controller.py
│   └── usuario_controller.py
├── models/
│   ├── __init__.py
│   ├── evento.py
│   ├── calendario.py
│   └── usuario.py
├── repository/
│   ├── __init__.py
│   ├── evento_repository.py
│   ├── calendario_repository.py
│   └── usuario_repository.py
├── schemas/
│   ├── __init__.py
│   ├── evento_schema.py
│   ├── calendario_schema.py
│   └── usuario_schema.py
├── service/
│   ├── __init__.py
│   ├── evento_service.py
│   ├── calendario_service.py
│   └── usuario_service.py
└── __init__.py
```

## 🚀 Getting Started / Comenzando

### Prerequisites / Requisitos Previos

#### Para la versión JavaScript/TypeScript:
- Node.js (v20 o superior)
- npm o yarn

#### Para la versión Python:
- Python 3.8 o superior
- pip (gestor de paquetes de Python)

### Installation / Instalación

#### JavaScript/TypeScript Version:
1. Clone the repository:
   ```bash
   git clone https://github.com/Killgreck/Agenda-ia.git
   cd Agenda-ia
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open your browser and navigate to `http://localhost:5000`

#### Python Version:
1. Clonar el repositorio:
   ```bash
   git clone https://github.com/Killgreck/Agenda-ia.git
   cd Agenda-ia
   ```

2. Crear un entorno virtual (opcional pero recomendado):
   ```bash
   python -m venv venv
   ```

3. Activar el entorno virtual:
   - En Windows:
     ```bash
     venv\Scripts\activate
     ```
   - En Linux/MacOS:
     ```bash
     source venv/bin/activate
     ```

4. Instalar las dependencias:
   ```bash
   pip install -r requirements.txt
   ```

## 🛠️ Development / Desarrollo

- **Running the JS app**: `npm run dev`
- **Building for production**: `npm run build`
- **Starting production server**: `npm run start`

## 📝 License / Licencia

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Contributing / Contribuciones

Contributions are welcome! Please feel free to submit a Pull Request.

## 📞 Contact / Contacto

- Developer: [Killgreck](https://github.com/Killgreck)
- Project Link: [https://github.com/Killgreck/Agenda-ia](https://github.com/Killgreck/Agenda-ia)
