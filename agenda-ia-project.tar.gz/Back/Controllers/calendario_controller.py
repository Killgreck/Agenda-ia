from ..repository.calendario_repository import CalendarioRepository

class CalendarioController:
    def __init__(self):
        self.repository = CalendarioRepository()
